package com.cleanup.todoc.di;

import com.cleanup.todoc.repository.Repository;

public class DI {

	private static Repository repository = new Repository();
	public static Repository getTaskRepository() {
		return repository;
	}
}
